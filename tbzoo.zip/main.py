import sys

sys.dont_write_bytecode = True

from hokireceh_claimer import base
from core.info import get_info
from core.task import process_check_in, process_do_project_task, process_do_normal_task, load_config
from core.mine import process_claim
from core.spin import process_spin
from core.draw import process_draw
from core.upgrade import process_upgrade

import time

config = load_config()

class TabiZoo:
    def __init__(self):
        # Get file directory
        self.data_file = base.file_path(file_name="data.txt")
        self.config_file = base.file_path(file_name="config.json")

        # Initialize line
        self.line = base.create_line(length=50)

        # Initialize banner
        self.banner = base.create_banner(game_name="TabiZoo")

        # Get config
        self.auto_check_in = base.get_config(
            config_file=self.config_file, config_name="auto-check-in"
        )

        self.auto_do_task = base.get_config(
            config_file=self.config_file, config_name="auto-do-task"
        )

        self.auto_claim = base.get_config(
            config_file=self.config_file, config_name="auto-claim"
        )

        self.auto_spin = base.get_config(
            config_file=self.config_file, config_name="auto-spin"
        )

        self.auto_draw = base.get_config(
            config_file=self.config_file, config_name="auto-draw"
        )

        self.auto_upgrade = base.get_config(
            config_file=self.config_file, config_name="auto-upgrade"
        )
        self.time_sleep = config.get("time_sleep", 60)

    def main(self):
        while True:
            base.clear_terminal()
            print(f"{base.yellow}TOOL SHARED BY FOREST ARMY (https://t.me/forestarmy)")
            data = open(self.data_file, "r").read().splitlines()
            num_acc = len(data)
            base.log(self.line)
            base.log(f"{base.green}Numer of accounts: {base.white}{num_acc}")

            for no, data in enumerate(data):
                base.log(self.line)
                base.log(f"{base.green}Account number: {base.white}{no+1}/{num_acc}")

                try:
                    # Info
                    get_info(data=data)

                    # Check in
                    if self.auto_check_in:
                        process_check_in(data=data)
                 
                    # Do task
                    if self.auto_do_task:
                        process_do_project_task(data=data)
                        process_do_normal_task(data=data)
                 
                    # Claim
                    if self.auto_claim:
                        process_claim(data=data)
                 
                    # Spin
                    if self.auto_spin:
                        process_spin(data=data, multiplier=1)

                    if self.auto_draw:
                        process_draw(data=data)
                  
                    # Upgrade
                    if self.auto_upgrade:
                        process_upgrade(data=data)
                  
                except Exception as e:
                    base.log(f"{base.red}F O R E S T A R M Y- Error: {base.white}{e}")

            print()
            wait_time = self.time_sleep * 60
            base.log(f"{base.yellow}Completed all accounts | Wait for {int(wait_time/60)} minutes!")
            time.sleep(wait_time)


if __name__ == "__main__":
    try:
        tabi = TabiZoo()
        tabi.main()
    except KeyboardInterrupt:
        base.log(f"{base.red}\nProcess interrupted by user. Exiting...")
    except Exception as e:
        base.log(f"{base.red}Error: {base.white}{e}")
