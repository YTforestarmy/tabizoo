import requests
import time

from hokireceh_claimer import base
from core.headers import headers
from core.info import get_info


def draw_info(data, proxies=None):
    url = "https://api.tabibot.com/api/lottery/v1/check?draw_type=free_draw&draw_times=1"

    try:
        response = requests.get(
            url=url, headers=headers(data=data), proxies=proxies, timeout=20
        )
        data = response.json()
        data = data["data"]
        return data
    except:
        return None


def play_draw(data, multiplier, proxies=None):
    url = "https://api.tabibot.com/api/lottery/v1/draw"
    payload = {"draw_type": "free_draw", "draw_times": multiplier}

    try:
        response = requests.post(
            url=url,
            headers=headers(data=data),
            json=payload,
            proxies=proxies,
            timeout=20,
        )
        data = response.json()
        data = data["data"]
        return data
    except:
        return None

def calculate_next_draw_cost(used_times, initial_cost):
    next_cost = initial_cost
    if used_times == 0:
        return initial_cost
    for _ in range(used_times):
        next_cost *= 2  # double the cost for each subsequent draw
    return next_cost

def process_draw(data, proxies=None):
    while True:
        info = draw_info(data=data, proxies=proxies)
        config_draw_max_times = info["config_draw_max_times"]
        free_draw_used_times = info["free_draw_used_times"]
        free_draw_unused_times = info["free_draw_unused_times"]

        energy = info["owned_zoo_amount"]
        next_draw_cost = calculate_next_draw_cost(free_draw_used_times, 10)
        # print(f"info:{info} {energy} {next_draw_cost}")
        if free_draw_used_times == config_draw_max_times or free_draw_unused_times == 0:
            base.log(f"{base.white}Auto draw: {base.red}No free draw times")
            break
        if energy is not None:
            if energy > next_draw_cost:
                res_play_draw = play_draw(
                    data=data, multiplier=1, proxies=proxies
                )
                materials = res_play_draw["basic_material"]
                next_draw_cost = res_play_draw["cost_zoo"] * 2
                if materials:
                    for material in materials:
                        material_name = material["material_name"]
                        quantity = material["quantity"]
                        base.log(
                            f"{base.white}Auto draw: {base.green}Success | Reward: {quantity} {material_name}"
                        )
                    get_info(data=data, proxies=proxies)
                    time.sleep(1)
                else:
                    base.log(f"{base.white}Auto draw: {base.red}Fail")
                    break
            else:
                base.log(f"{base.white}Auto draw: {base.red}No energy to draw")
                break
        else:
            base.log(f"{base.white}Auto draw: {base.red}Energy data not found")
            break
